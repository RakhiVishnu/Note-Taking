@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card">
               

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <nav class="navbar navbar-expand-lg navbar-light bg-success">
                        <a class="navbar-brand" href="#">
                        <p style="font-size: 30px;">
                            THE NOTES TAKER
                        </p>
  
                        </a>
                    </nav>
                    <form action="{{ route('Note.store') }}" method="POST" enctype="multipart/form-data">
                                                @csrf
                    <div class="container my-3">
                    <h1>Take your Notes here</h1>
                    <div class="card">

                        <div class="card-body">
                            <h5 class="card-title">
                                Add a Note
                            
                            </h5>
                            <div class="form-group">
                                <textarea class="form-control" 
                                    id="addTxt"  name="addTxt" rows="3" require>
                                </textarea>
                            </div>
                            <button class="btn btn-primary" 
                                id="addBtn" type="submit" style=
                                "background-color:green">
                                Add Note
                            </button>
                        </div>
                        
                    </div>
                    <hr>
                    </div>  
                    
                </div>
                </form>    
            </div>
        </div>
        
        <div class="col-md-7">
        <div class="table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                           <th>ID</th> 
                           <th>Date</th> 
                          <th>Note</th>
                       
                          <th>Action</th>
                        
                        </tr>
                      </thead>


                      <tbody>
                      @foreach ($notes as $note)
                        <tr>
                           <td>{!! $note->id !!}</td>
                           <td>{!! $note->created_at !!}</td> 
                          <td>{!! $note->note !!}</td>
                        
                          <form action="{{ route('Note',$note->id) }}" method="POST">
                             @csrf
                            <td class=" last">
                            <a href="{{ route('Note.edit',$note->id) }}"><i class="fa fa-pencil"></i></a>
                            @method('DELETE')
                            <button type="submit"  style="border: none;"><i class="fa fa-close"></i></button> 
                          
                            </td>
                            </form>
                          
                        </tr>
                      @endforeach  
                      </tbody>
                    </table>
                    </div>
        </div>



    
    </div>
</div>
@endsection
